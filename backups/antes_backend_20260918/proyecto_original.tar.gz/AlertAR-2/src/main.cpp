#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ---------- Pines ----------
#define TRIG1 26
#define ECHO1 25

#define TRIG2 19
#define ECHO2 21

#define PIN_AGUA 34

#define LED_VERDE 17
#define LED_AMARILLO 5
#define LED_ROJO 18

#define SDA_PIN 32
#define SCL_PIN 33

// Tiempo que esperamos antes de empezar a reportar fallas
constexpr unsigned long TIEMPO_INICIALIZACION_MS = 2000;

LiquidCrystal_I2C lcd(0x27, 16, 2);

#include "logica.h"

alertar::Agua agua;
alertar::Carril carril1;
alertar::Carril carril2;


// ============================================================
// ULTRASONIDO
// ============================================================

float leerDistanciaCm(int trig, int echo) {
  digitalWrite(trig, LOW);
  delayMicroseconds(2);

  digitalWrite(trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(trig, LOW);

  const unsigned long duracion = pulseIn(echo, HIGH, 30000UL);

  if (duracion == 0) {
    return -1.0f;
  }

  // Conversión usando velocidad del sonido ~343 m/s.
  float distancia = duracion * 0.0343f / 2.0f;

  // Wokwi puede quedar apenas por encima de 400 cm
  // en el extremo del slider.
  if (distancia > 400.0f && distancia <= 410.0f) {
    distancia = 400.0f;
  }

  return distancia;
}


// ============================================================
// LCD
// ============================================================

void mostrarLCD(const char *linea1, const char *linea2) {

  static String anterior1;
  static String anterior2;

  // Evitamos limpiar/redibujar el LCD innecesariamente
  if (anterior1 == linea1 &&
      anterior2 == linea2) {
    return;
  }

  anterior1 = linea1;
  anterior2 = linea2;

  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print(linea1);

  lcd.setCursor(0, 1);
  lcd.print(linea2);
}


// ============================================================
// TELEMETRÍA
// ============================================================

void imprimirAltura(const alertar::Carril &carril) {

  if (carril.valido) {
    Serial.print(carril.altura);
  } else {
    Serial.print("null");
  }
}


void enviarJSON(const alertar::Estado &estado) {

  // Una línea JSON por muestra.
  // No imprimir texto adicional por Serial porque rompería
  // un lector externo de telemetría.

  Serial.print("{\"codigo\":\"");
  Serial.print(estado.codigo);

  Serial.print("\",\"diagnostico\":\"");
  Serial.print(estado.diagnostico);

  Serial.print("\",\"obstruccion_carril1_cm\":");
  imprimirAltura(carril1);

  Serial.print(",\"obstruccion_carril2_cm\":");
  imprimirAltura(carril2);

  Serial.print(",\"sensor1_valido\":");
  Serial.print(carril1.valido ? "true" : "false");

  Serial.print(",\"sensor2_valido\":");
  Serial.print(carril2.valido ? "true" : "false");

  Serial.print(",\"agua_activa\":");
  Serial.print(agua.confirmada ? "true" : "false");

  Serial.print(",\"agua_pendiente\":");
  Serial.print(agua.pendiente() ? "true" : "false");

  Serial.println("}");
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  Serial.begin(115200);

  // ---------- Ultrasonido 1 ----------
  pinMode(TRIG1, OUTPUT);
  pinMode(ECHO1, INPUT);

  // ---------- Ultrasonido 2 ----------
  pinMode(TRIG2, OUTPUT);
  pinMode(ECHO2, INPUT);

  digitalWrite(TRIG1, LOW);
  digitalWrite(TRIG2, LOW);

  // ---------- Sensor de agua ----------
  pinMode(PIN_AGUA, INPUT);

  // ---------- LEDs ----------
  pinMode(LED_VERDE, OUTPUT);
  pinMode(LED_AMARILLO, OUTPUT);
  pinMode(LED_ROJO, OUTPUT);

  // Durante inicialización:
  // amarillo encendido
  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_AMARILLO, HIGH);
  digitalWrite(LED_ROJO, LOW);

  // ---------- LCD ----------
  Wire.begin(SDA_PIN, SCL_PIN);

  lcd.init();
  lcd.backlight();

  mostrarLCD(
      "PRECAUCION",
      "Iniciando..."
  );
}


// ============================================================
// LOOP
// ============================================================

void loop() {

  const uint32_t ahora = millis();

  // ----------------------------------------------------------
  // Sensor de agua
  // ----------------------------------------------------------

  const int lecturaAgua =
      analogRead(PIN_AGUA);

  agua.actualizar(
      lecturaAgua,
      ahora
  );


  // ----------------------------------------------------------
  // Ultrasonido carril 1
  // ----------------------------------------------------------

  const float distancia1 =
      leerDistanciaCm(TRIG1, ECHO1);

  carril1.actualizar(
      distancia1,
      millis()
  );


  // Separar disparos para evitar ecos cruzados
  delay(60);


  // ----------------------------------------------------------
  // Ultrasonido carril 2
  // ----------------------------------------------------------

  const float distancia2 =
      leerDistanciaCm(TRIG2, ECHO2);

  carril2.actualizar(
      distancia2,
      millis()
  );


  // ==========================================================
  // PERÍODO DE INICIALIZACIÓN
  // ==========================================================

  if (millis() < TIEMPO_INICIALIZACION_MS) {

    digitalWrite(
        LED_VERDE,
        LOW
    );

    digitalWrite(
        LED_AMARILLO,
        HIGH
    );

    digitalWrite(
        LED_ROJO,
        LOW
    );

    mostrarLCD(
        "PRECAUCION",
        "Iniciando..."
    );

    delay(200);

    return;
  }


  // ==========================================================
  // DECISIÓN DEL SISTEMA
  // ==========================================================

  const alertar::Estado estado =
      alertar::decidir(
          carril1,
          carril2,
          agua
      );


  // ----------------------------------------------------------
  // LEDs
  // ----------------------------------------------------------

  digitalWrite(
      LED_VERDE,
      estado.color == alertar::VERDE
  );

  digitalWrite(
      LED_AMARILLO,
      estado.color == alertar::AMARILLO
  );

  digitalWrite(
      LED_ROJO,
      estado.color == alertar::ROJO
  );


  // ----------------------------------------------------------
  // LCD
  // ----------------------------------------------------------

  mostrarLCD(
      estado.linea1,
      estado.linea2
  );


  // ----------------------------------------------------------
  // Telemetría
  // ----------------------------------------------------------

  enviarJSON(estado);


  // Aproximadamente 260-320 ms por ciclo,
  // dependiendo de los ecos.
  delay(200);
}